extends Node3D

const WorldScript = preload("res://scripts/world.gd")
const ControlsScript = preload("res://scripts/touch_controls.gd")
const SaveStore = preload("res://scripts/save_store.gd")
var catalog: Array[Dictionary] = []
var world: TravelWorld
var controls: TravelTouchControls
var state: Dictionary
var ui: Control
var heading: Label
var status: Label
var hint: Label
var interact_button: Button
var menu: PanelContainer
var menu_list: VBoxContainer
var search: LineEdit
var license_dialog: AcceptDialog
var description_dialog: AcceptDialog
var current_poi: Dictionary = {}
var autosave_time := 0.0
var save_enabled := true

func _ready() -> void:
	_load_catalog()
	var loaded := SaveStore.load_data()
	state = loaded.data
	_build_ui()
	if not loaded.ok:
		status.text = loaded.error + " Bấm Lưu để bắt đầu ghi phiên mới."
		save_enabled = false
	var entry := catalog[0]
	for candidate in catalog:
		if candidate.id == state.region_id:
			entry = candidate
			break
	enter_region(entry.id, false)

func _load_catalog() -> void:
	var path := "res://data/geography/regions.json"
	if FileAccess.file_exists(path):
		var data = JSON.parse_string(FileAccess.get_file_as_string(path))
		var entries = data if data is Array else data.get("regions", []) if data is Dictionary else []
		for entry in entries:
			if entry is Dictionary and entry.get("id") is String and entry.get("name") is String:
				catalog.append(entry)
	if catalog.is_empty():
		catalog.append({"id": "hanoi", "name": "Hà Nội", "type": "province", "scene_style": "city", "detail_level": "prototype"})

func enter_region(id: String, save_previous: bool = true) -> bool:
	var selected: Dictionary = {}
	for entry in catalog:
		if entry.id == id:
			selected = entry
			break
	if selected.is_empty():
		return false
	if world and save_previous:
		capture_position()
	if world:
		remove_child(world)
		world.queue_free()
	world = WorldScript.new()
	add_child(world)
	world.build(selected)
	state.region_id = id
	if state.positions.has(id):
		var position: Dictionary = state.positions[id]
		world.player.position = Vector3(position.x, maxf(position.y, world.terrain_height(position.x, position.z) + 0.1), position.z)
		world.player.yaw = position.yaw
		world.player.pitch = position.pitch
		world.player.update_camera()
	if is_instance_valid(heading):
		heading.text = str(selected.name) + "  ·  " + ("KHU MẪU HÀ NỘI" if str(id).to_lower().replace("-", "").replace("_", "") in ["hanoi", "01"] else "CẢNH MINH HỌA 3D")
	close_menu()
	if save_previous and save_enabled:
		save_now()
	return true

func capture_position() -> void:
	if not world or not world.player:
		return
	var p := world.player.position
	state.positions[state.region_id] = {"x": clampf(p.x, -41, 41), "y": clampf(p.y, -5, 40), "z": clampf(p.z, -41, 41), "yaw": world.player.yaw, "pitch": world.player.pitch}

func save_now() -> bool:
	capture_position()
	var success := SaveStore.save_data(state)
	status.text = "Đã lưu offline trên thiết bị · " + str(state.visited.size()) + " dấu khám phá" if success else "Chưa lưu được. Hãy thử lại trước khi thoát."
	return success

func _process(delta: float) -> void:
	if not world:
		return
	var paused := menu.visible or description_dialog.visible or (is_instance_valid(license_dialog) and license_dialog.visible)
	controls.enabled = not paused
	if paused:
		world.player.move_input = Vector2.ZERO
	else:
		var keyboard := Vector2(float(Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT)) - float(Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT)), float(Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN)) - float(Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP)))
		world.player.move_input = (keyboard + controls.movement).limit_length(1.0)
	current_poi = world.nearest_poi()
	interact_button.visible = not current_poi.is_empty() and not paused
	if not current_poi.is_empty():
		interact_button.text = ("✓ Xem lại · " if state.visited.has(current_poi.id) else "Khám phá · ") + str(current_poi.title)
	hint.text = "Đi gần cột mốc vàng để tham quan  ·  " + str(_current_visit_count()) + "/" + str(world.pois.size()) + " dấu tại đây"
	autosave_time += delta
	if autosave_time > 5 and save_enabled:
		autosave_time = 0
		save_now()

func _current_visit_count() -> int:
	var count := 0
	for poi in world.pois:
		if state.visited.has(poi.id):
			count += 1
	return count

func interact() -> bool:
	var poi := world.nearest_poi()
	if poi.is_empty():
		return false
	if not state.visited.has(poi.id):
		state.visited.append(poi.id)
	description_dialog.title = poi.title
	description_dialog.dialog_text = poi.description + "\n\nĐã ghi một dấu khám phá trong nhật ký offline."
	description_dialog.popup_centered(Vector2i(620, 270))
	controls.cancel_touches()
	if save_enabled:
		save_now()
	return true

func open_menu() -> void:
	menu.show()
	controls.enabled = false
	controls.cancel_touches()
	_refresh_menu()

func close_menu() -> void:
	if is_instance_valid(menu):
		menu.hide()
	if is_instance_valid(controls):
		controls.cancel_touches()
		controls.enabled = true

func _refresh_menu(_text: String = "") -> void:
	for child in menu_list.get_children():
		menu_list.remove_child(child)
		child.queue_free()
	var query := search.text.strip_edges().to_lower()
	for entry in catalog:
		if not query.is_empty() and not str(entry.name).to_lower().contains(query):
			continue
		var button := Button.new()
		var kind := "ĐẢO / QUẦN ĐẢO" if str(entry.get("type", "")) == "island" else "TỈNH / THÀNH"
		button.text = str(entry.name) + "   ·   " + kind + "   → Vào cảnh 3D"
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		button.custom_minimum_size.y = 46
		button.pressed.connect(enter_region.bind(str(entry.id)))
		menu_list.add_child(button)

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	ui = Control.new()
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(ui)
	var theme := Theme.new()
	theme.default_font_size = 18
	var button_style := StyleBoxFlat.new()
	button_style.bg_color = Color("214c3f")
	button_style.set_corner_radius_all(9)
	button_style.content_margin_left = 15
	button_style.content_margin_right = 15
	button_style.content_margin_top = 9
	button_style.content_margin_bottom = 9
	theme.set_stylebox("normal", "Button", button_style)
	var hover := button_style.duplicate()
	hover.bg_color = Color("3b6a52")
	theme.set_stylebox("hover", "Button", hover)
	theme.set_stylebox("pressed", "Button", hover)
	theme.set_color("font_color", "Button", Color("fff4df"))
	ui.theme = theme
	controls = ControlsScript.new()
	ui.add_child(controls)
	controls.camera_drag.connect(func(motion: Vector2):
		if world and not menu.visible and not description_dialog.visible:
			world.player.look(motion))
	var bar := PanelContainer.new()
	bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	bar.offset_left = 18
	bar.offset_top = 16
	bar.offset_right = -18
	bar.offset_bottom = 98
	bar.add_theme_stylebox_override("panel", _panel_style(Color(0.06, 0.17, 0.14, 0.92)))
	ui.add_child(bar)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	bar.add_child(row)
	var names := VBoxContainer.new()
	names.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(names)
	heading = Label.new()
	heading.add_theme_font_size_override("font_size", 23)
	names.add_child(heading)
	var subtitle := Label.new()
	subtitle.text = "DỌC MIỀN VIỆT 3D · OFFLINE · Đi bộ và ngắm cảnh"
	subtitle.add_theme_font_size_override("font_size", 14)
	names.add_child(subtitle)
	var map_button := Button.new()
	map_button.text = "Đổi địa điểm"
	map_button.pressed.connect(open_menu)
	row.add_child(map_button)
	var save_button := Button.new()
	save_button.text = "Lưu"
	save_button.pressed.connect(func():
		save_enabled = true
		save_now())
	row.add_child(save_button)
	var reset_button := Button.new()
	reset_button.text = "Về lối vào"
	reset_button.pressed.connect(func():
		world.player.position = Vector3(0, world.terrain_height(0, 15) + 0.4, 15)
		world.player.velocity = Vector3.ZERO
		if save_enabled:
			save_now())
	row.add_child(reset_button)
	var footer_background := Panel.new()
	footer_background.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	footer_background.offset_left = 208
	footer_background.offset_right = -16
	footer_background.offset_top = -102
	footer_background.offset_bottom = -7
	footer_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	footer_background.add_theme_stylebox_override("panel", _panel_style(Color(0.06, 0.17, 0.14, 0.85)))
	ui.add_child(footer_background)
	var footer := VBoxContainer.new()
	footer.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	footer.offset_left = 220
	footer.offset_right = -25
	footer.offset_top = -94
	footer.offset_bottom = -14
	footer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(footer)
	hint = Label.new()
	hint.add_theme_font_size_override("font_size", 17)
	hint.add_theme_color_override("font_shadow_color", Color.BLACK)
	hint.add_theme_constant_override("shadow_offset_x", 1)
	hint.add_theme_constant_override("shadow_offset_y", 2)
	footer.add_child(hint)
	status = Label.new()
	status.text = "Chưa có thay đổi · Lưu offline tự động mỗi 5 giây"
	status.add_theme_font_size_override("font_size", 13)
	footer.add_child(status)
	var instructions := Label.new()
	instructions.text = "Joystick trái / WASD: đi bộ · Kéo phải / giữ chuột phải: xoay camera"
	instructions.add_theme_font_size_override("font_size", 13)
	footer.add_child(instructions)
	interact_button = Button.new()
	interact_button.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	interact_button.offset_left = -610
	interact_button.offset_right = -24
	interact_button.offset_top = -158
	interact_button.offset_bottom = -106
	interact_button.pressed.connect(interact)
	interact_button.hide()
	ui.add_child(interact_button)
	menu = PanelContainer.new()
	menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu.offset_left = 120
	menu.offset_right = -120
	menu.offset_top = 112
	menu.offset_bottom = -40
	menu.add_theme_stylebox_override("panel", _panel_style(Color("173f35")))
	ui.add_child(menu)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	menu.add_child(column)
	var title := Label.new()
	title.text = "34 tỉnh/thành + 13 vùng đảo · Nội dung đang phát triển"
	title.add_theme_font_size_override("font_size", 25)
	column.add_child(title)
	var disclaimer := Label.new()
	disclaimer.text = "Mỗi địa danh vào được cảnh 3D minh họa riêng. Chưa số hóa địa hình / công trình thực địa.\nĐảo có địa hình nổi, bờ cát và điểm tham quan; không khẳng định đường bờ hay tỷ lệ thực."
	disclaimer.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	disclaimer.add_theme_font_size_override("font_size", 14)
	column.add_child(disclaimer)
	search = LineEdit.new()
	search.placeholder_text = "Tìm tên tỉnh, thành phố hoặc đảo…"
	search.text_changed.connect(_refresh_menu)
	column.add_child(search)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	column.add_child(scroll)
	menu_list = VBoxContainer.new()
	menu_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(menu_list)
	var licenses_button := Button.new()
	licenses_button.text = "Giấy phép & nguồn dữ liệu"
	licenses_button.pressed.connect(_show_licenses)
	column.add_child(licenses_button)
	var close := Button.new()
	close.text = "Trở lại tham quan"
	close.pressed.connect(close_menu)
	column.add_child(close)
	menu.hide()
	description_dialog = AcceptDialog.new()
	description_dialog.exclusive = true
	description_dialog.min_size = Vector2i(580, 260)
	description_dialog.ok_button_text = "Tiếp tục đi bộ"
	ui.add_child(description_dialog)

func _show_licenses() -> void:
	controls.cancel_touches()
	if not is_instance_valid(license_dialog):
		license_dialog = AcceptDialog.new()
		license_dialog.title = "Giấy phép & nguồn dữ liệu · Offline"
		license_dialog.exclusive = true
		license_dialog.ok_button_text = "Đóng"
		ui.add_child(license_dialog)
		var text := TextEdit.new()
		text.text = preload("res://scripts/licenses.gd").full_text()
		text.editable = false
		text.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
		text.custom_minimum_size = Vector2(700, 360)
		text.add_theme_font_size_override("font_size", 15)
		license_dialog.add_child(text)
	license_dialog.popup_centered(Vector2i(800, 460))

func _panel_style(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.set_corner_radius_all(12)
	style.content_margin_left = 18
	style.content_margin_right = 18
	style.content_margin_top = 12
	style.content_margin_bottom = 12
	return style

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		if state and world and save_enabled:
			save_now()
		if controls:
			controls.cancel_touches()
