# Kiến trúc Dọc miền Việt 3D

## Quyết định kỹ thuật

Game chuyển sang khám phá 3D góc nhìn thứ ba: người chơi trực tiếp điều khiển nhân vật đi tham quan, đến gần điểm quan tâm để tương tác và khám phá Việt Nam. Android và iOS là đích phát hành, chơi offline sau khi cài. Dùng **Godot 4.6.3, GDScript và renderer Compatibility** trong thư mục `game3d/`. Compatibility là điểm xuất phát để hỗ trợ nhiều GPU di động; chất lượng và hiệu năng phải được đo trên thiết bị thực, không suy ra từ tên renderer.

Prototype React Native/Expo v0.1 ở gốc repository được giữ để so sánh; không dùng làm lõi 3D và không xóa mã nguồn hoặc APK cũ. `game3d/` có project, scene, scripts và dữ liệu riêng. Không nhúng engine vào React Native trong giai đoạn này: cách đó tăng rủi ro vòng đời, input, render và build mà chưa mang lại lợi ích cho vòng chơi chính.

## Công cụ đã kiểm tra

- Engine có sẵn: `/opt/godot/4.6.3/Godot_v4.6.3-stable_linux.x86_64`. Lệnh `--headless --version` trả về `4.6.3.stable.official.7d41c59c4`.
- Android SDK hiện có tại `/workspace/android-sdk`: platform 36, build-tools 35.0.0 và 36.0.0, platform-tools, NDK và CMake. JDK 17 tại `/workspace/java/jdk-17.0.17+10`.
- `ANDROID_HOME`, `ANDROID_SDK_ROOT` và `JAVA_HOME` chưa được export trong shell lúc kiểm tra. Script build cần chọn các đường dẫn đã có; không cài thêm một bộ SDK/JDK chỉ vì thiếu biến môi trường.
- Chưa tìm thấy Godot export templates ở các đường dẫn người dùng chuẩn lúc kiểm tra ban đầu. Export Android cần templates **đúng 4.6.3 stable**; engine chạy headless thành công không chứng minh khả năng export đã có.
- Linux không có Xcode. Build, ký và kiểm thử iOS cần macOS/Xcode cùng chứng chỉ/provisioning phù hợp cho cách phân phối được chọn.

Không in hoặc đưa khóa ký, mật khẩu, token vào repository hoặc tài liệu. Giữ kiểm tra TLS/chữ ký/checksum khi lấy templates hay tool bổ sung. Các kết quả build thực tế thuộc tài liệu validation, không coi checklist trong tài liệu này là kết quả đã đạt.

## Phạm vi thế giới và dữ liệu

Danh mục phủ **34 tỉnh/thành theo cơ cấu hiện hành** và các điểm đảo/quần đảo đã biên tập là mục tiêu dữ liệu. Phải phân biệt ba khái niệm:

| Lớp | Ý nghĩa | Bằng chứng hoàn thành |
| --- | --- | --- |
| Registry | ID, tên, loại địa danh, vùng, nguồn và độ phủ | Dữ liệu được kiểm tra trùng/thiếu, có nguồn và ngày rà soát |
| Scene có thể chơi | Môi trường 3D có nhân vật, va chạm và tương tác | Chạy được, đi lại và hoàn thành tương tác tại scene đó |
| Nội dung tham quan | Địa danh, mô hình, văn hóa và nhiệm vụ địa phương | Nội dung được biên tập, asset có quyền sử dụng và được kiểm thử |

Có đủ tên trong registry không đồng nghĩa đã dựng đủ tỉnh hoặc đảo 3D. Mỗi scene mẫu là một khu tham quan thu nhỏ, không phải mô phỏng toàn bộ diện tích địa phương. Dữ liệu đảo cần ghi rõ mức bao phủ và nguồn; không tự tuyên bố đã bao phủ mọi đảo. Không dùng bản đồ cách điệu như bản đồ hành chính, công cụ định vị hay bằng chứng về đường biên.

Mục tiêu vertical slice: một khu tham quan đại diện đủ đi bộ, xoay camera, va chạm, nhận biết và tương tác POI, lưu/khôi phục tiến trình; đồng thời có bộ chọn địa phương và trạng thái rõ cho nội dung chưa được dựng riêng. Scene thủ tục dùng lại phải được ghi là môi trường minh họa, không giả làm địa danh được tái hiện chính xác.

## Cấu trúc dự án và thành phần

```text
game3d/
  project.godot           Cấu hình engine, renderer, input và scene khởi động
  scenes/                 Scene thế giới/nhân vật/giao diện nếu tách file
  scripts/                Điều khiển, thế giới, UI và lưu trữ
  data/                   Registry và POI được đóng gói
  assets/                 Mesh, material, âm thanh, font có giấy phép
  export_presets.cfg      Preset export không chứa bí mật
```

Các thành phần có thể gộp trong prototype; khi mở rộng cần giữ ranh giới trách nhiệm sau:

- **World:** lắp khu tham quan, spawn nhân vật/POI, collision tĩnh, ánh sáng và giới hạn thế giới.
- **Player:** `CharacterBody3D`, vận tốc theo camera, trọng lực và `move_and_slide`; không di chuyển trực tiếp bằng teleport mỗi frame để né collision.
- **Camera:** pivot và `Camera3D`; `SpringArm3D` hoặc truy vấn vật lý tránh xuyên tường, giới hạn pitch và khoảng cách.
- **Touch input:** joystick trái và kéo camera phải; theo dõi touch ID riêng để di chuyển và nhìn cùng lúc. Mở menu hoặc mất focus phải xóa input đang giữ. Có WASD/phím mũi tên và chuột để kiểm tra trên desktop.
- **POI:** vùng tương tác hoặc khoảng cách có kiểm tra, tên và nút tương tác khi đủ gần; không hoàn thành từ xa bằng cách chỉ chọn tên trong menu.
- **HUD/menu:** joystick, nút tương tác, tiến trình, tạm dừng/bộ chọn địa phương, hướng dẫn và nút quay về vị trí an toàn.
- **Save:** đọc/ghi local và nâng cấp schema, tách khỏi nội dung địa danh.

Màn hình landscape, UI theo safe area và co giãn bằng anchor/container. Input ở UI không được đồng thời xoay camera hoặc kích hoạt thao tác thế giới.

## Lưu trữ và offline

Mọi mesh, dữ liệu, font và âm thanh bắt buộc đi trong bản cài/PCK. Không dùng API bản đồ, tải tile, đăng nhập, quảng cáo hoặc CDN trong đường chơi. Chuyển địa phương chỉ nạp nội dung cục bộ đã đóng gói. Sau khi cài, mở lạnh trong chế độ máy bay phải vào được scene và chơi tiếp.

Tiến trình ở `user://` cần có schema version, địa phương hiện tại, POI đã khám phá và các thiết lập điều khiển. Dùng ID địa danh/POI ổn định, không dùng tên hiển thị làm khóa. Nếu lưu tọa độ, chỉ phục hồi khi world version và vị trí hợp lệ; nếu không, đặt nhân vật ở spawn an toàn. Không chuyển trực tiếp AsyncStorage của prototype Expo sang save Godot vì hai game có schema và vòng chơi khác nhau.

Ghi ra tệp tạm rồi thay tệp chính hoặc giữ bản sao gần nhất để giảm nguy cơ cắt ngang khi đóng ứng dụng. Kiểm tra lỗi mở/ghi/parse và báo rõ khi không lưu được. Chỉ đặt cờ hoàn thành POI một lần; tương tác lại không nhân thưởng. Lưu sau tương tác/chuyển vùng và khi app vào nền; checkpoint vị trí theo chu kỳ nếu cần, không ghi đĩa mỗi frame. Xóa tiến trình phải xác nhận và chỉ xóa tệp của game.

## Chunk và ngân sách mobile

Không dựng toàn bộ Việt Nam trong một scene luôn hoạt động. Giai đoạn đầu dùng một khu tham quan hoạt động tại một thời điểm, chuyển qua màn bản đồ. Khi khu lớn hơn, chia chunk theo khoảng cách; nạp trước vùng sắp tới bằng resource loader, giải phóng vùng cũ và giữ save ngoài scene. Nội dung cục bộ có thể được nạp dần mà vẫn hoàn toàn offline.

Low-poly, material dùng lại, ít transparency, ánh sáng đơn giản và collision primitive là mặc định. Không tạo collision concave động cho nhân vật. Hạn chế bóng thời gian thực trên thiết bị yếu; thử LOD, visibility range hoặc MultiMesh cho cây/cảnh vật lặp lại. Đo frame time, RAM và kích thước gói trên thiết bị; mục tiêu ban đầu 30 FPS ổn định trên máy mục tiêu, không công bố đạt trước profiling. Danh sách 34 địa phương không cho phép nạp 34 cảnh cùng lúc.

## Build Android và iOS

Android sử dụng engine/templates cùng phiên bản. Ưu tiên export APK debug bằng templates tiêu chuẩn cho vòng thử đầu, tránh Android Gradle custom build khi chưa cần plugin. Cấu hình SDK/JDK trong editor settings hoặc script cục bộ được tài liệu hóa, preset package ID riêng với prototype Expo nếu cần cài song song. Artifact 3D phải có tên khác APK v0.1 để không nhầm hai trò chơi. Kiểm tra manifest, ABI, chữ ký, tệp game nhúng và checksum; kiểm tra gói không thay thế kiểm tra chạy trên thiết bị.

Ví dụ lệnh sau chỉ áp dụng khi đã có preset `Android` và templates được cài:

```bash
cd /workspace/TravelVietnamese/game3d
/opt/godot/4.6.3/Godot_v4.6.3-stable_linux.x86_64 --headless --editor --import
/opt/godot/4.6.3/Godot_v4.6.3-stable_linux.x86_64 --headless --path . --export-debug Android ../artifacts/doc-mien-viet-3d-debug.apk
```

iOS xuất project Xcode trên công cụ hỗ trợ rồi build/ký trên macOS. Phải chạy kiểm tra touch, safe area, renderer và lưu dữ liệu trên iPhone/iPad riêng. APK chạy được không chứng minh iOS chạy được. Không cam kết IPA hay phát hành cửa hàng khi chưa có toolchain, quyền ký và kiểm thử tương ứng.

## Kiểm chứng kiến trúc

1. Import/headless parse không có lỗi GDScript; chạy scene nhiều frame, xác nhận các node thiết yếu được dựng.
2. Kiểm tra desktop có ảnh thực: nhân vật di chuyển có va chạm, camera theo và tránh vật cản, POI chỉ tương tác khi ở gần.
3. Kiểm tra đa chạm trên Android: vừa giữ joystick vừa kéo camera, thả ngón/menu/background không để nhân vật tự chạy.
4. Save/reload: khám phá POI, đóng mở lại; vị trí hợp lệ hoặc spawn an toàn, nội dung đã khám phá giữ nguyên. Save hỏng có đường khôi phục rõ.
5. Kiểm tra registry khác scene coverage; không quảng bá danh sách tên thành thế giới đã hoàn thiện.
6. Build APK và thử mở lạnh offline trên thiết bị; đo FPS/RAM. iOS có báo cáo kiểm thử riêng khi có máy hỗ trợ.

Các mục là điều kiện cần thực thi, chưa phải tuyên bố đã đạt. Hạn chế, lỗi và kết quả đo phải được ghi vào báo cáo validation của build cụ thể.
