class_name TravelTouchControls
extends Control

signal camera_drag(delta: Vector2)
var joystick_id := -1
var camera_id := -1
var joystick_origin := Vector2.ZERO
var joystick_tip := Vector2.ZERO
var movement := Vector2.ZERO
var enabled := true
var mouse_look := false
const RADIUS := 68.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func cancel_touches() -> void:
	joystick_id = -1
	camera_id = -1
	movement = Vector2.ZERO
	mouse_look = false
	queue_redraw()

func _input(event: InputEvent) -> void:
	if not enabled:
		return
	if event is InputEventScreenTouch:
		if not event.pressed:
			if event.index == joystick_id:
				joystick_id = -1
				movement = Vector2.ZERO
			if event.index == camera_id:
				camera_id = -1
		elif event.position.y > size.y * 0.45 and event.position.x < size.x * 0.38 and joystick_id == -1:
			joystick_id = event.index
			joystick_origin = event.position
			joystick_tip = event.position
		elif event.position.x > size.x * 0.44 and event.position.y > 130 and event.position.y < size.y - 110 and camera_id == -1:
			camera_id = event.index
		queue_redraw()
	elif event is InputEventScreenDrag:
		if event.index == joystick_id:
			movement = ((event.position - joystick_origin) / RADIUS).limit_length(1.0)
			joystick_tip = joystick_origin + movement * RADIUS
			queue_redraw()
		elif event.index == camera_id:
			camera_drag.emit(event.relative)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT:
		mouse_look = event.pressed
	elif event is InputEventMouseMotion and mouse_look:
		camera_drag.emit(event.relative)

func _draw() -> void:
	if not enabled:
		return
	var center := joystick_origin if joystick_id >= 0 else Vector2(115, size.y - 120)
	var tip := joystick_tip if joystick_id >= 0 else center
	draw_circle(center, RADIUS, Color(0.08, 0.22, 0.18, 0.35))
	draw_arc(center, RADIUS, 0, TAU, 48, Color(1, 0.97, 0.88, 0.8), 2)
	draw_circle(tip, 28, Color(0.92, 0.72, 0.35, 0.85))
